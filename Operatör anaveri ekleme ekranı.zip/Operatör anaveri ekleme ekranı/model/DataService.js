sap.ui.define([], function () {
    "use strict";

    var aOperators = [
        {
            personnelNo: "10001",
            firstName: "Ali",
            lastName: "Yılmaz",
            status: "ACTIVE",
            password: "Ali10001!",
            createdAt: "2026-09-01T08:30:00",
            updatedAt: "2026-09-01T08:30:00",
        },
        {
            personnelNo: "10002",
            firstName: "Ayşe",
            lastName: "Kaya",
            status: "ACTIVE",
            password: "Ayse10002!",
            createdAt: "2026-09-02T09:15:00",
            updatedAt: "2026-09-04T14:20:00",
        },
        {
            personnelNo: "10003",
            firstName: "Mehmet",
            lastName: "Demir",
            status: "PASSIVE",
            password: "Mehmet10003!",
            createdAt: "2026-09-03T10:45:00",
            updatedAt: "2026-09-05T11:10:00",
        },
    ];

    function clone(oValue) {
        return JSON.parse(JSON.stringify(oValue));
    }

    function toSearchText(sValue) {
        return (sValue || "").toLocaleLowerCase("tr-TR").trim();
    }

    function getListItem(oOperator) {
        return {
            personnelNo: oOperator.personnelNo,
            firstName: oOperator.firstName,
            lastName: oOperator.lastName,
            status: oOperator.status,
            passwordMasked: "••••••••",
            passwordVisible: false,
            createdAt: oOperator.createdAt,
            updatedAt: oOperator.updatedAt,
        };
    }

    function getDateValue(sValue) {
        return sValue ? new Date(sValue).getTime() : null;
    }

    return {
        searchOperators: function (oFilters) {
            var oSafeFilters = oFilters || {};
            var sPersonnelNo = toSearchText(oSafeFilters.personnelNo);
            var sFirstName = toSearchText(oSafeFilters.firstName);
            var sLastName = toSearchText(oSafeFilters.lastName);
            var sStatus = oSafeFilters.status || "ALL";
            var iCreatedFrom = getDateValue(oSafeFilters.createdAtFrom);
            var iCreatedTo = getDateValue(oSafeFilters.createdAtTo);
            var iUpdatedFrom = getDateValue(oSafeFilters.updatedAtFrom);
            var iUpdatedTo = getDateValue(oSafeFilters.updatedAtTo);

            var aResult = aOperators.filter(function (oOperator) {
                var iCreatedAt = getDateValue(oOperator.createdAt);
                var iUpdatedAt = getDateValue(oOperator.updatedAt);
                var bPersonnelMatches =
                    !sPersonnelNo || toSearchText(oOperator.personnelNo).includes(sPersonnelNo);
                var bFirstNameMatches =
                    !sFirstName || toSearchText(oOperator.firstName).includes(sFirstName);
                var bLastNameMatches =
                    !sLastName || toSearchText(oOperator.lastName).includes(sLastName);
                var bStatusMatches = sStatus === "ALL" || oOperator.status === sStatus;
                var bCreatedFromMatches = iCreatedFrom === null || iCreatedAt >= iCreatedFrom;
                var bCreatedToMatches = iCreatedTo === null || iCreatedAt <= iCreatedTo + 86400000 - 1;
                var bUpdatedFromMatches = iUpdatedFrom === null || iUpdatedAt >= iUpdatedFrom;
                var bUpdatedToMatches = iUpdatedTo === null || iUpdatedAt <= iUpdatedTo + 86400000 - 1;

                return (
                    bPersonnelMatches &&
                    bFirstNameMatches &&
                    bLastNameMatches &&
                    bStatusMatches &&
                    bCreatedFromMatches &&
                    bCreatedToMatches &&
                    bUpdatedFromMatches &&
                    bUpdatedToMatches
                );
            });

            return Promise.resolve(clone(aResult.map(getListItem)));
        },

        getOperator: function (sPersonnelNo) {
            var oOperator = aOperators.find(function (oItem) {
                return oItem.personnelNo === sPersonnelNo;
            });

            if (!oOperator) {
                return Promise.reject(new Error("Operatör kaydı bulunamadı."));
            }

            return Promise.resolve(clone(oOperator));
        },

        saveOperator: function (oPayload) {
            var sPersonnelNo = (oPayload.personnelNo || "").trim();
            var sFirstName = (oPayload.firstName || "").trim();
            var sLastName = (oPayload.lastName || "").trim();
            var sStatus = oPayload.status || "ACTIVE";
            var sPassword = (oPayload.password || "").trim();
            var oNow = new Date().toISOString();
            var oExisting = aOperators.find(function (oItem) {
                return oItem.personnelNo === sPersonnelNo;
            });

            if (oPayload.isEdit) {
                if (!oExisting) {
                    return Promise.reject(new Error("Operatör kaydı bulunamadı."));
                }

                oExisting.firstName = sFirstName;
                oExisting.lastName = sLastName;
                oExisting.status = sStatus;
                oExisting.password = sPassword;
                oExisting.updatedAt = oNow;
            } else {
                if (oExisting) {
                    return Promise.reject(new Error("Bu Sicil No zaten kayıtlıdır."));
                }

                aOperators.push({
                    personnelNo: sPersonnelNo,
                    firstName: sFirstName,
                    lastName: sLastName,
                    status: sStatus,
                    password: sPassword,
                    createdAt: oNow,
                    updatedAt: oNow,
                });
            }

            return Promise.resolve(clone(getListItem(oExisting || aOperators[aOperators.length - 1])));
        },

        deleteOperator: function (sPersonnelNo) {
            var iIndex = aOperators.findIndex(function (oItem) {
                return oItem.personnelNo === sPersonnelNo;
            });

            if (iIndex === -1) {
                return Promise.reject(new Error("Operatör kaydı bulunamadı."));
            }

            aOperators.splice(iIndex, 1);
            return Promise.resolve(true);
        },

        getPassword: function (sPersonnelNo) {
            var oOperator = aOperators.find(function (oItem) {
                return oItem.personnelNo === sPersonnelNo;
            });

            if (!oOperator) {
                return Promise.reject(new Error("Operatör kaydı bulunamadı."));
            }

            return Promise.resolve(oOperator.password);
        },

        getTemplateColumns: function () {
            return ["Sicil No", "Ad", "Soyad", "Şifre"];
        },

        importOperators: function (aRows) {
            var aErrors = [];
            var iSuccessCount = 0;

            (aRows || []).forEach(function (oRow, iIndex) {
                var iRowNumber = iIndex + 2;
                var sPersonnelNo = (oRow.personnelNo || "").trim();
                var sFirstName = (oRow.firstName || "").trim();
                var sLastName = (oRow.lastName || "").trim();
                var sPassword = (oRow.password || "").trim();

                if (!sPersonnelNo) {
                    aErrors.push({ rowNumber: iRowNumber, message: "Sicil No boş." });
                    return;
                }

                if (!sFirstName) {
                    aErrors.push({ rowNumber: iRowNumber, message: "Ad boş." });
                    return;
                }

                if (!sLastName) {
                    aErrors.push({ rowNumber: iRowNumber, message: "Soyad boş." });
                    return;
                }

                if (!sPassword) {
                    aErrors.push({ rowNumber: iRowNumber, message: "Şifre boş." });
                    return;
                }

                if (
                    aOperators.some(function (oItem) {
                        return oItem.personnelNo === sPersonnelNo;
                    })
                ) {
                    aErrors.push({ rowNumber: iRowNumber, message: "Sicil No zaten mevcut." });
                    return;
                }

                var oNow = new Date().toISOString();
                aOperators.push({
                    personnelNo: sPersonnelNo,
                    firstName: sFirstName,
                    lastName: sLastName,
                    status: "ACTIVE",
                    password: sPassword,
                    createdAt: oNow,
                    updatedAt: oNow,
                });
                iSuccessCount += 1;
            });

            return Promise.resolve({
                totalRows: (aRows || []).length,
                successCount: iSuccessCount,
                errorCount: aErrors.length,
                errors: aErrors,
            });
        },
    };
});
