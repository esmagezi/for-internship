sap.ui.define(["sap/ui/model/json/JSONModel"], function (JSONModel) {
    "use strict";

    return {
        createViewModel: function () {
            return new JSONModel({
                busy: false,
                filters: {
                    personnelNo: "",
                    firstName: "",
                    lastName: "",
                    status: "ALL",
                },
                operators: [],
                operatorCountText: "",
                dialog: {
                    personnelNo: "",
                    firstName: "",
                    lastName: "",
                    status: "ACTIVE",
                    password: "",
                    passwordVisible: false,
                    isEdit: false,
                },
                validation: {
                    personnelNo: { state: "None", text: "" },
                    firstName: { state: "None", text: "" },
                    lastName: { state: "None", text: "" },
                    password: { state: "None", text: "" },
                },
                importResult: null,
                importSummaryText: "",
            });
        },
    };
});
