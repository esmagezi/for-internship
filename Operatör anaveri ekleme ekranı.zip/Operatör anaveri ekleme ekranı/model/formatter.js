sap.ui.define([], function () {
    "use strict";

    return {
        formatDate: function (sValue) {
            if (!sValue) {
                return "";
            }

            var oDate = new Date(sValue);
            if (isNaN(oDate.getTime())) {
                return sValue;
            }

            return new Intl.DateTimeFormat("tr-TR", {
                day: "2-digit",
                month: "2-digit",
                year: "numeric",
                hour: "2-digit",
                minute: "2-digit",
            }).format(oDate);
        },

        formatStatusText: function (sStatus) {
            return sStatus === "ACTIVE" ? "Aktif" : "Pasif";
        },

        formatStatusState: function (sStatus) {
            return sStatus === "ACTIVE" ? "Success" : "Error";
        },
    };
});
