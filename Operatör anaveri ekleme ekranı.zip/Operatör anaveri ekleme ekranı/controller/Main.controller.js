sap.ui.define(
    [
        "sap/ui/core/mvc/Controller",
        "sap/ui/core/Fragment",
        "sap/m/MessageBox",
        "sap/m/MessageToast",
        "OperatorAnaveriEklemeEkrani/model/DataService",
        "OperatorAnaveriEklemeEkrani/model/models",
        "OperatorAnaveriEklemeEkrani/model/formatter",
    ],
    function (Controller, Fragment, MessageBox, MessageToast, DataService, models, formatter) {
        "use strict";

        return Controller.extend("OperatorAnaveriEklemeEkrani.controller.Main", {
            formatter: formatter,

            onInit: function () {
                var oViewModel = models.createViewModel();
                this.getView().setModel(oViewModel, "viewModel");
                this._loadOperators();
            },

            _getBundle: function () {
                return this.getView().getModel("i18n").getResourceBundle();
            },

            _text: function (sKey, aArgs) {
                return this._getBundle().getText(sKey, aArgs);
            },

            _loadOperators: async function () {
                var oViewModel = this.getView().getModel("viewModel");
                oViewModel.setProperty("/busy", true);

                try {
                    var aOperators = await DataService.searchOperators(oViewModel.getProperty("/filters"));
                    oViewModel.setProperty("/operators", aOperators);
                    oViewModel.setProperty("/operatorCountText", this._text("operatorCount", [aOperators.length]));
                } catch (oError) {
                    MessageBox.error(oError.message || this._text("msgLoadError"));
                    oViewModel.setProperty("/operators", []);
                    oViewModel.setProperty("/operatorCountText", this._text("operatorCount", [0]));
                } finally {
                    oViewModel.setProperty("/busy", false);
                }
            },

            _resetDialog: function (oData) {
                var oViewModel = this.getView().getModel("viewModel");
                oViewModel.setProperty(
                    "/dialog",
                    Object.assign(
                        {
                            personnelNo: "",
                            firstName: "",
                            lastName: "",
                            status: "ACTIVE",
                            password: "",
                            passwordVisible: false,
                            isEdit: false,
                        },
                        oData || {},
                    ),
                );
                oViewModel.setProperty("/validation", {
                    personnelNo: { state: "None", text: "" },
                    firstName: { state: "None", text: "" },
                    lastName: { state: "None", text: "" },
                    password: { state: "None", text: "" },
                });
            },

            onApplyFilters: function () {
                this._loadOperators();
            },

            onClearFilters: function () {
                this.getView().getModel("viewModel").setProperty("/filters", {
                    personnelNo: "",
                    firstName: "",
                    lastName: "",
                    status: "ALL",
                });
                this._loadOperators();
            },

            onRefresh: function () {
                this._loadOperators().then(
                    function () {
                        MessageToast.show(this._text("msgRefreshSuccess"));
                    }.bind(this),
                );
            },

            onAddOperator: function () {
                this._resetDialog();
                this._openOperatorDialog();
            },

            onEditOperator: function (oEvent) {
                var oOperator = oEvent.getSource().getBindingContext("viewModel").getObject();

                DataService.getOperator(oOperator.personnelNo).then(
                    function (oDetail) {
                        this._resetDialog({
                            personnelNo: oDetail.personnelNo,
                            firstName: oDetail.firstName,
                            lastName: oDetail.lastName,
                            status: oDetail.status,
                            password: oDetail.password,
                            passwordVisible: false,
                            isEdit: true,
                        });
                        this._openOperatorDialog();
                    }.bind(this),
                );
            },

            _openOperatorDialog: function () {
                if (!this._pOperatorDialog) {
                    this._pOperatorDialog = Fragment.load({
                        id: this.getView().getId(),
                        name: "OperatorAnaveriEklemeEkrani.view.fragments.OperatorDialog",
                        controller: this,
                    });
                }

                this._pOperatorDialog.then(
                    function (oDialog) {
                        this.getView().addDependent(oDialog);
                        oDialog.open();
                    }.bind(this),
                );
            },

            onToggleDialogPassword: function () {
                var oViewModel = this.getView().getModel("viewModel");
                var bVisible = oViewModel.getProperty("/dialog/passwordVisible");
                oViewModel.setProperty("/dialog/passwordVisible", !bVisible);
            },

            onToggleRowPassword: async function (oEvent) {
                var oViewModel = this.getView().getModel("viewModel");
                var oContext = oEvent.getSource().getBindingContext("viewModel");
                var oOperator = oContext.getObject();

                if (oOperator.passwordVisible) {
                    oContext.getModel().setProperty(oContext.getPath() + "/passwordVisible", false);
                    return;
                }

                try {
                    var sPassword = await DataService.getPassword(oOperator.personnelNo);
                    oContext.getModel().setProperty(oContext.getPath() + "/passwordValue", sPassword);
                    oContext.getModel().setProperty(oContext.getPath() + "/passwordVisible", true);
                } catch (oError) {
                    MessageBox.error(oError.message || this._text("msgPasswordLoadError"));
                }
            },

            onCloseOperatorDialog: function () {
                if (this._pOperatorDialog) {
                    this._pOperatorDialog.then(function (oDialog) {
                        oDialog.close();
                    });
                }
            },

            onSaveOperator: async function () {
                var oViewModel = this.getView().getModel("viewModel");
                var oDialog = oViewModel.getProperty("/dialog");
                var aErrors = [];

                if (!oDialog.personnelNo.trim()) {
                    aErrors.push("personnelNo");
                }

                if (!oDialog.firstName.trim()) {
                    aErrors.push("firstName");
                }

                if (!oDialog.lastName.trim()) {
                    aErrors.push("lastName");
                }

                if (!oDialog.password.trim()) {
                    aErrors.push("password");
                }

                oViewModel.setProperty(
                    "/validation/personnelNo/state",
                    aErrors.includes("personnelNo") ? "Error" : "None",
                );
                oViewModel.setProperty(
                    "/validation/personnelNo/text",
                    aErrors.includes("personnelNo") ? this._text("validationPersonnelNo") : "",
                );
                oViewModel.setProperty(
                    "/validation/firstName/state",
                    aErrors.includes("firstName") ? "Error" : "None",
                );
                oViewModel.setProperty(
                    "/validation/firstName/text",
                    aErrors.includes("firstName") ? this._text("validationFirstName") : "",
                );
                oViewModel.setProperty(
                    "/validation/lastName/state",
                    aErrors.includes("lastName") ? "Error" : "None",
                );
                oViewModel.setProperty(
                    "/validation/lastName/text",
                    aErrors.includes("lastName") ? this._text("validationLastName") : "",
                );
                oViewModel.setProperty(
                    "/validation/password/state",
                    aErrors.includes("password") ? "Error" : "None",
                );
                oViewModel.setProperty(
                    "/validation/password/text",
                    aErrors.includes("password") ? this._text("validationPassword") : "",
                );

                if (aErrors.length) {
                    MessageBox.error(
                        aErrors
                            .map(function (sField) {
                                return oViewModel.getProperty("/validation/" + sField + "/text");
                            })
                            .join("\n"),
                    );
                    return;
                }

                oViewModel.setProperty("/busy", true);
                try {
                    await DataService.saveOperator(oDialog);
                    MessageToast.show(this._text(oDialog.isEdit ? "msgUpdateSuccess" : "msgCreateSuccess"));
                    this.onCloseOperatorDialog();
                    await this._loadOperators();
                } catch (oError) {
                    MessageBox.error(oError.message || this._text("msgSaveError"));
                } finally {
                    oViewModel.setProperty("/busy", false);
                }
            },

            onDeleteOperator: function (oEvent) {
                var oOperator = oEvent.getSource().getBindingContext("viewModel").getObject();

                MessageBox.confirm(this._text("msgDeleteConfirm", [oOperator.personnelNo]), {
                    onClose: function (sAction) {
                        if (sAction === MessageBox.Action.OK) {
                            this._deleteOperator(oOperator.personnelNo);
                        }
                    }.bind(this),
                });
            },

            _deleteOperator: async function (sPersonnelNo) {
                var oViewModel = this.getView().getModel("viewModel");
                oViewModel.setProperty("/busy", true);

                try {
                    await DataService.deleteOperator(sPersonnelNo);
                    MessageToast.show(this._text("msgDeleteSuccess"));
                    await this._loadOperators();
                } catch (oError) {
                    MessageBox.error(oError.message || this._text("msgDeleteError"));
                } finally {
                    oViewModel.setProperty("/busy", false);
                }
            },

            onDownloadTemplate: function () {
                var sExcelXml =
                    '<?xml version="1.0" encoding="UTF-8"?>' +
                    '<?mso-application progid="Excel.Sheet"?>' +
                    '<Workbook xmlns="urn:schemas-microsoft-com:office:spreadsheet" ' +
                    'xmlns:ss="urn:schemas-microsoft-com:office:spreadsheet">' +
                    '<Worksheet ss:Name="Operatörler"><Table>' +
                    '<Row>' +
                    '<Cell><Data ss:Type="String">Sicil No</Data></Cell>' +
                    '<Cell><Data ss:Type="String">Ad</Data></Cell>' +
                    '<Cell><Data ss:Type="String">Soyad</Data></Cell>' +
                    '<Cell><Data ss:Type="String">Şifre</Data></Cell>' +
                    '</Row>' +
                    '<Row>' +
                    '<Cell><Data ss:Type="String"></Data></Cell>' +
                    '<Cell><Data ss:Type="String"></Data></Cell>' +
                    '<Cell><Data ss:Type="String"></Data></Cell>' +
                    '<Cell><Data ss:Type="String"></Data></Cell>' +
                    '</Row>' +
                    '</Table></Worksheet></Workbook>';

                var oBlob = new Blob(["\ufeff", sExcelXml], {
                    type: "application/vnd.ms-excel;charset=utf-8;",
                });
                var sUrl = URL.createObjectURL(oBlob);
                var oLink = document.createElement("a");
                oLink.href = sUrl;
                oLink.download = "MES022_Operator_Sablonu.xls";
                document.body.appendChild(oLink);
                oLink.click();
                document.body.removeChild(oLink);
                URL.revokeObjectURL(sUrl);
            },

            onImportOperators: function () {
                this._openImportDialog();
            },

            _openImportDialog: function () {
                var oViewModel = this.getView().getModel("viewModel");
                oViewModel.setProperty("/importResult", null);
                oViewModel.setProperty("/importSummaryText", "");

                if (!this._pImportDialog) {
                    this._pImportDialog = Fragment.load({
                        id: this.getView().getId(),
                        name: "OperatorAnaveriEklemeEkrani.view.fragments.ImportDialog",
                        controller: this,
                    });
                }

                this._pImportDialog.then(
                    function (oDialog) {
                        this.getView().addDependent(oDialog);
                        oDialog.open();
                    }.bind(this),
                );
            },

            onCloseImportDialog: function () {
                if (this._pImportDialog) {
                    this._pImportDialog.then(function (oDialog) {
                        oDialog.close();
                    });
                }
            },

            onImportFileChange: function (oEvent) {
                var oFile = oEvent.getParameter("files") && oEvent.getParameter("files")[0];

                if (!oFile) {
                    return;
                }

                var sFileName = oFile.name.toLowerCase();
                if (!sFileName.endsWith(".csv") && !sFileName.endsWith(".xls")) {
                    MessageBox.error(this._text("msgImportFormat"));
                    return;
                }

                var oReader = new FileReader();
                oReader.onload = function (oLoadEvent) {
                    var sContent = oLoadEvent.target.result.replace(/^\ufeff/, "");
                    var aRows = [];

                    if (sFileName.endsWith(".xls")) {
                        var oDocument = new DOMParser().parseFromString(sContent, "text/xml");
                        var aSpreadsheetRows = Array.prototype.slice.call(oDocument.getElementsByTagName("Row"));

                        if (!aSpreadsheetRows.length) {
                            oDocument = new DOMParser().parseFromString(sContent, "text/html");
                            aSpreadsheetRows = Array.prototype.slice.call(oDocument.querySelectorAll("table tr"));
                        }

                        aRows = aSpreadsheetRows.slice(1).map(function (oRow) {
                            var aCells = Array.prototype.slice
                                .call(oRow.getElementsByTagName("Cell"))
                                .map(function (oCell) {
                                    var oData = oCell.getElementsByTagName("Data")[0];
                                    return (oData || oCell).textContent.trim();
                                });

                            if (!aCells.length) {
                                aCells = Array.prototype.slice
                                    .call(oRow.querySelectorAll("td, th"))
                                    .map(function (oCell) {
                                        return oCell.textContent.trim();
                                    });
                            }

                            return {
                                personnelNo: aCells[0] || "",
                                firstName: aCells[1] || "",
                                lastName: aCells[2] || "",
                                password: aCells[3] || "",
                            };
                        }).filter(function (oRow) {
                            return oRow.personnelNo || oRow.firstName || oRow.lastName || oRow.password;
                        });
                    } else {
                        var aLines = sContent
                            .split(/\r?\n/)
                            .filter(function (sLine) {
                                return sLine.trim();
                            });

                        aRows = aLines.slice(1).map(function (sLine) {
                            var aCells = sLine.split(/\t|;/);
                            return {
                                personnelNo: (aCells[0] || "").trim(),
                                firstName: (aCells[1] || "").trim(),
                                lastName: (aCells[2] || "").trim(),
                                password: (aCells[3] || "").trim(),
                            };
                        });
                    }

                    DataService.importOperators(aRows).then(
                        function (oResult) {
                            var oViewModel = this.getView().getModel("viewModel");
                            oViewModel.setProperty("/importResult", oResult);
                            oViewModel.setProperty(
                                "/importSummaryText",
                                this._text("msgImportSummary", [
                                    oResult.totalRows,
                                    oResult.successCount,
                                    oResult.errorCount,
                                ]),
                            );
                            this._loadOperators();
                        }.bind(this),
                    );
                }.bind(this);
                oReader.readAsText(oFile, "UTF-8");
            },
        });
    },
);
