# MES022 Operatör Anaveri Ekleme Ekranı — Staj Raporu Yazım Planı

## Kullanım Amacı

Bu dosya, `MES022 - Operatör Anaveri Ekleme Ekranı` için 30 iş günü ve toplam 240 saatlik staj raporunun bir yapay zekâ tarafından hazırlanması amacıyla oluşturulmuş Türkçe çalışma planıdır.

> **Önemli kural:** Bu Markdown dosyası Türkçedir; ancak bu dosyayı kullanarak hazırlanacak nihai staj raporu tamamen İngilizce yazılmalıdır.

Bu planı kullanacak yapay zekâ:

- Nihai staj raporunu İngilizce yazmalıdır.
- Anlatımı 4. sınıf bilgisayar mühendisliği öğrencisinin seviyesine uygun tutmalıdır.
- Teknik kavramları açık ve anlaşılır biçimde açıklamalıdır.
- Kodda gerçekten bulunan özellikleri tamamlanmış çalışma olarak anlatmalıdır.
- Geliştirilmemiş özellikleri yapılmış gibi göstermemelidir.
- Mevcut prototip ile önerilen veya gelecekte yapılabilecek geliştirmeleri birbirinden ayırmalıdır.
- Kodda bulunmayan veritabanı, API, backend servisi, yetkilendirme sistemi veya şirket süreci uydurmamalıdır.
- Gerçek şifre, kişisel bilgi, token veya gizli bilgileri rapora eklememelidir.
- Her iş gününde farklı ve anlamlı bir çalışma anlatmalıdır.
- Her gün için yapılan çalışmayı, öğrenilen bilgileri, karşılaşılan sorunları, çözümü ve gün sonunda elde edilen çıktıyı açıklamalıdır.
- Teknik açıklamalarda ilgili dosya adlarını kullanmalıdır.

---

# 1. Proje Bilgileri

## 1.1 Proje Başlığı

**Bir Üretim Yürütme Sistemi İçin Operatör Anaveri Yönetim Modülünün Geliştirilmesi**

Alternatif başlık:

**Operatör Anaveri Ekleme Ekranının Tasarlanması ve Geliştirilmesi**

## 1.2 Proje Konusu

Bu projede, bir Manufacturing Execution System (MES) içerisinde operatör kayıtlarının yönetilmesini sağlayan web tabanlı ekran incelenmiş ve geliştirilmiştir.

Ekranın kodda doğrulanan temel işlevleri:

- Operatör kayıtlarını listeleme
- Sicil numarası, ad, soyad ve duruma göre filtreleme
- Yeni operatör ekleme
- Mevcut operatörü düzenleme
- Operatör silme
- Operatör durumunu aktif veya pasif olarak yönetme
- Şifreyi maskeli gösterme ve kullanıcı isteğiyle görüntüleme
- Excel uyumlu şablon indirme
- CSV ve XLS dosyalarından toplu veri aktarma
- Toplu aktarım sonucunu gösterme
- Satır bazlı aktarım hatalarını gösterme
- Zorunlu alan doğrulaması
- Aynı sicil numarasının tekrar eklenmesini engelleme
- Başarı ve hata mesajları gösterme
- İşlem sırasında ekranı meşgul gösterme
- Türkçe ve İngilizce dil kaynaklarını kullanma

## 1.3 Teknik Bilgiler

| Bilgi | Değer |
|---|---|
| Ekran adı | Operatör Anaveri Ekleme Ekranı |
| Teknoloji | SAPUI5, JavaScript, XML View |
| Mimari | MVC |
| Ana görünüm | `view/Main.view.xml` |
| Ana kontrolcü | `controller/Main.controller.js` |
| Veri servisi | `model/DataService.js` |
| Görünüm modeli | `model/models.js` |
| Operatör formu | `view/fragments/OperatorDialog.fragment.xml` |
| İçe aktarma penceresi | `view/fragments/ImportDialog.fragment.xml` |
| Uygulama sürümü | `1.0.0` |
| Minimum UI5 sürümü | `1.145.0` |

---

# 2. Yapay Zekâya Verilecek Ana Talimat

Aşağıdaki talimat doğrudan rapor yazacak yapay zekâya verilebilir:

> Bu Markdown dosyasındaki planı ve doğrulanmış proje kapsamını kullanarak 30 iş günü ve toplam 240 saatlik bilgisayar mühendisliği staj raporu hazırla.
>
> **Nihai raporu tamamen İngilizce yaz.** Bu Markdown dosyası Türkçe hazırlanmış bir çalışma planıdır; raporun dili İngilizce olmalıdır.
>
> Raporun konusu, ` Operator Master Data Entry Screen` adlı SAPUI5 tabanlı web modülünün incelenmesi, geliştirilmesi, test edilmesi ve dokümante edilmesidir.
>
> Raporu hem günlük staj defteri hem de teknik proje raporu biçiminde hazırla. Her gün için aşağıdaki başlıkları kullan:
>
> - Topic of the day
> - Work completed
> - Technologies and files used
> - Knowledge gained
> - Problems encountered
> - Solution
> - Result achieved at the end of the day
>
> Raporu yalnızca bu planda ve kaynak kodda doğrulanabilen bilgilerle sınırlandır. Kodda bulunmayan veritabanı tabloları, API adresleri, HTTP metotları, kullanıcı rolleri, backend servisleri veya şirket süreçleri uydurma.
>
> Mevcut `DataService.js` dosyasının örnek verileri bellekte tutan prototip bir servis katmanı olduğunu açıkça belirt. Bu yapıyı gerçek üretim veritabanı gibi anlatma. Backend veya veritabanı entegrasyonunu yalnızca önerilen geliştirme veya gelecek çalışma olarak yaz.
>
> Raporda mevcut özellikleri; listeleme, filtreleme, ekleme, düzenleme, silme, doğrulama, şifre maskeleme, şablon indirme, CSV/XLS aktarımı, aktarım hata raporlama, busy-state yönetimi ve dil kaynakları üzerinden açıkla.
>
> Raporun sonunda şu bölümleri oluştur:
>
> 1. General Evaluation
> 2. Technical Achievements
> 3. Problems and Solutions
> 4. Test Results
> 5. Project Limitations
> 6. Recommended Future Improvements
> 7. Conclusion
>
> Raporu öğrencinin projeyi inceleyip geliştirdiğini gösterecek şekilde yaz; ancak gerçek kodla desteklenmeyen iddialarda bulunma.

---

# 3. Otuz İş Günlük Çalışma Planı

Her staj günü 8 saat olarak kabul edilmelidir. Toplam süre:

**30 gün × 8 saat = 240 saat**

## 1. Hafta — Projeyi ve Geliştirme Ortamını Tanıma

### 1. Gün — ERP, SAP ve MES Kavramlarının İncelenmesi

Anlatılacak konular:

- ERP kavramının tanımı ve işletmelerdeki rolü
- SAP'nin ERP sistemleri içindeki yeri
- SAP modüllerinin genel çalışma mantığı
- MES kavramının tanımı
- ERP ile MES arasındaki farklar ve ilişki
- Üretim, satın alma, stok ve kalite süreçlerinin birbirleriyle bağlantısı
- Bir fabrikanın uçtan uca süreçlerinin bilgi sistemleriyle yönetilmesi

İlk gün yapılacak uygulamalı çalışma:

- Yurt dışından ham madde satın alan örnek bir fabrika senaryosu oluşturulması
- Ham madde ihtiyacının oluşması
- Satın alma sürecinin başlatılması
- Tedarikçi ve sipariş bilgilerinin oluşturulması
- Ham maddenin fabrikaya ulaşması
- Depoya kabul ve stok kaydının yapılması
- Üretim emrinin oluşturulması
- Ham maddenin üretime sevk edilmesi
- Üretim, kalite kontrol ve mamul stok süreçlerinin modellenmesi

Günün çıktısı:

- ERP, SAP ve MES kavramları arasındaki ilişki öğrenilmiştir.
- Yurt dışından ham madde tedarik eden örnek bir fabrikanın süreç kapsamı belirlenmiştir.
- Süreçte kullanılacak aktörler, veriler ve temel iş adımları çıkarılmıştır.

### 2. Gün — Fabrika Sürecinin Mock Data ve Diyagramlarla Modellenmesi

Anlatılacak konular:

- Senaryo için mock data oluşturma yaklaşımı
- Ham madde, tedarikçi, satın alma siparişi, sevkiyat, stok, üretim emri ve kalite kontrol verilerinin modellenmesi
- Süreç adımlarının birbirleriyle ilişkilendirilmesi
- Veri akışının ve sorumlulukların belirlenmesi
- ERP, SAP ve MES katmanlarının senaryo üzerindeki görevleri
- Süreç diyagramı ve veri akış diyagramı hazırlama
- Gerçek şirket verileri yerine örnek verilerle çalışma

Uygulamalı çalışma:

- Kendi oluşturduğum mock data kullanılarak örnek fabrika sürecinin simüle edilmesi
- Ham madde satın alma sürecinin diyagramla gösterilmesi
- Depo kabulünden üretim hattına kadar olan akışın modellenmesi
- MES ekranlarının üretim sürecindeki konumunun gösterilmesi
- Hazırlanan senaryo, diyagramlar ve açıklamaların bir dokümanda birleştirilmesi
- Dokümanın ekip üyelerine sunulması ve alınan geri bildirimlerin değerlendirilmesi

Günün çıktısı:

- Yurt dışından ham madde alan bir fabrikanın uçtan uca süreç dokümanı hazırlanmıştır.
- Mock data kullanılarak satın alma, stok, üretim ve kalite süreçleri simüle edilmiştir.
- Süreç diyagramları ve veri akışları hazırlanarak ekip ile paylaşılmıştır.

### 3. Gün — SAP ve MES Ekranlarının İncelenmesi

Anlatılacak konular:

- Ekipte kullanılan SAP ve MES ekranlarının genel amaçları
- SAP'nin kurumsal kaynak planlama süreçlerindeki rolü
- MES ekranlarının üretim sahasındaki rolü
- Ana veri ve işlem verisi arasındaki fark
- Operatör, malzeme, iş emri, stok ve üretim bilgilerinin ilişkisi
- İncelenen ekranların önceki gün hazırlanan fabrika senaryosundaki karşılıkları
- Ekranlar arasındaki bilgi akışının takip edilmesi

Günün çıktısı:

- Ekipte kullanılan SAP ve MES ekranlarının temel amaçları öğrenilmiştir.
- Hazırlanan fabrika senaryosu ile gerçek uygulama ekranları arasında bağlantı kurulmuştur.

### 4. Gün — MES Web Uygulamalarının ve SAPUI5 Yapısının İncelenmesi

Anlatılacak konular:

- Projedeki MES web ekranlarının genel yapısı
- SAPUI5 frameworkünün temel bileşenleri
- XML View ve JavaScript Controller ilişkisi
- Model-View-Controller mimarisi
- `Main.view.xml`, `Main.controller.js`, `models.js` ve `DataService.js` dosyalarının görevleri
- Fragment kullanım amacı
- Ekranların kullanıcı işlemlerini nasıl yönettiği
- Ekipte kullanılan kodlama ve proje düzeninin incelenmesi

Günün çıktısı:

- MES web ekranlarının SAPUI5 ve MVC mimarisiyle geliştirildiği öğrenilmiştir.
- Ekranların görünüm, kontrolcü ve veri katmanları arasındaki ilişki anlaşılmıştır.

### 5. Gün — MES022 Operatör Anaveri Ekleme Ekranının Proje Kapsamının Belirlenmesi

Anlatılacak konular:

- `MES022` ekranının amacı
- Operatör anaverisinin üretim süreçlerindeki rolü
- Operatör listeleme, filtreleme, ekleme, düzenleme ve silme işlemleri
- Dosyadan toplu operatör aktarımı
- Ekranın önceki günlerde incelenen SAP ve MES süreçlerindeki yeri
- Ekran klasör yapısının incelenmesi
- `Component.js`, `index.html` ve `manifest.json`
- `view`, `controller`, `model` ve `i18n` klasörleri
- Projenin staj süresince ele alınacak kapsamının belirlenmesi

Günün çıktısı:

- MES022 ekranının fonksiyonel kapsamı belirlenmiştir.
- Ekranın ilgili üretim ve operatör yönetimi süreçlerindeki yeri anlaşılmıştır.
- Stajın kalan günleri için geliştirme, test ve dokümantasyon planı oluşturulmuştur.

---

## 2. Hafta — Model, Listeleme ve Filtreleme

### 6. Gün — Görünüm Modelinin Hazırlanması

Anlatılacak konular:

- `JSONModel` kullanımı
- `busy` değişkeni
- `filters` nesnesi
- `operators` listesi
- `dialog` nesnesi
- `validation` nesnesi
- `importResult` ve `importSummaryText`
- XML binding ile model arasındaki ilişki

Günün çıktısı:

- Ekranın durumunu ve form verilerini tutan model yapısı anlaşılmıştır.

### 7. Gün — Başlangıçta Veri Yükleme

Anlatılacak konular:

- `onInit` fonksiyonu
- Görünüm modelinin oluşturulması
- `_loadOperators` fonksiyonunun çağrılması
- Operatör listesinin `/operators` alanına yazılması
- Operatör sayısının gösterilmesi
- Veri yüklenirken `busy` değerinin kullanılması
- Listeleme hatalarının ele alınması

Günün çıktısı:

- Ekran açılışındaki veri yükleme akışı açıklanmıştır.

### 8. Gün — Operatör Tablosu

Anlatılacak konular:

- `sap.m.Table` kullanımı
- `viewModel>/operators` binding yapısı
- Sicil numarası, ad ve soyad kolonları
- Şifre kolonu
- Durum kolonu
- Oluşturulma ve güncellenme tarihi kolonları
- Düzenleme ve silme düğmeleri
- Boş liste durumunda gösterilen mesaj
- Formatter ile tarih ve durum gösterimi

Günün çıktısı:

- Operatör kayıtlarının tablo içinde gösterilmesi sağlanmıştır.

### 9. Gün — Filtreleme İşlemleri

Anlatılacak konular:

- Sicil numarasına göre filtreleme
- Ada göre filtreleme
- Soyada göre filtreleme
- Aktif/pasif/tümü durum filtresi
- `onApplyFilters`
- Filtre değerlerinin görünüm modelinde tutulması
- Küçük/büyük harf duyarsız arama
- Türkçe karakterlerle metin normalizasyonu
- Filtreleme sonucunda tablonun yenilenmesi

Günün çıktısı:

- Kullanıcının aradığı operatör kayıtlarını filtreleyebilmesi sağlanmıştır.

### 10. Gün — Filtreleri Temizleme ve Yenileme

Anlatılacak konular:

- `onClearFilters`
- Filtrelerin varsayılan değerlere döndürülmesi
- `ALL`, `ACTIVE` ve `PASSIVE` değerleri
- `onRefresh`
- Yenileme başarı mesajı
- İşlem sırasında düğmelerin pasif duruma alınması

Günün çıktısı:

- Filtre temizleme ve liste yenileme akışları test edilmiştir.

---

## 3. Hafta — Ekleme, Düzenleme ve Doğrulama

### 11. Gün — Operatör Formunun Tasarlanması

Anlatılacak konular:

- `OperatorDialog.fragment.xml`
- Dialog tabanlı form yapısı
- Sicil numarası alanı
- Ad alanı
- Soyad alanı
- Şifre alanı
- Durum seçim alanı
- Kaydet ve iptal düğmeleri
- Yeni kayıtta varsayılan `ACTIVE` durumu
- Form alanlarının modele bağlanması

Günün çıktısı:

- Operatör ekleme ve düzenleme formu hazırlanmıştır.

### 12. Gün — Zorunlu Alan Doğrulaması

Anlatılacak konular:

- `onSaveOperator`
- Sicil numarası kontrolü
- Ad kontrolü
- Soyad kontrolü
- Şifre kontrolü
- `trim` ile boşlukların temizlenmesi
- Alanların `Error` durumuna alınması
- Alan bazlı hata metinleri
- Birden fazla hatanın birlikte gösterilmesi

Günün çıktısı:

- Eksik alanlarla kayıt yapılması engellenmiştir.

### 13. Gün — Yeni Operatör Kaydetme

Anlatılacak konular:

- Yeni kayıt ve düzenleme modunun ayrılması
- `isEdit` değişkeni
- `DataService.saveOperator`
- Aynı sicil numarasının kontrol edilmesi
- Başarılı kayıt mesajı
- Dialogun kapatılması
- Listeyi yeniden yükleme
- Kayıt sırasında busy durumu

Günün çıktısı:

- Geçerli bir operatör kaydının eklenmesi test edilmiştir.

### 14. Gün — Mevcut Operatörü Düzenleme

Anlatılacak konular:

- Tablo satırındaki düzenleme düğmesi
- `onEditOperator`
- Binding context üzerinden satır verisinin alınması
- `getOperator`
- Dialogun mevcut verilerle doldurulması
- Düzenlemede sicil numarasının değiştirilememesi
- Ad, soyad, şifre ve durumun güncellenmesi
- Güncelleme sonrası listenin yenilenmesi

Günün çıktısı:

- Mevcut operatör bilgilerinin düzenlenmesi sağlanmıştır.

### 15. Gün — Şifre Gösterme ve Gizleme

Anlatılacak konular:

- Dialog içindeki şifre göster/gizle düğmesi
- `onToggleDialogPassword`
- `Password` ve `Text` input türleri
- Tablo satırındaki şifre göster/gizle işlemi
- `onToggleRowPassword`
- Başlangıçta maskeli şifre gösterimi
- `getPassword`
- Şifre yükleme hatası
- Açık şifre gösteriminin güvenlik riskleri

Günün çıktısı:

- Şifre görünürlük davranışı ve güvenlik sınırlılıkları değerlendirilmiştir.

---

## 4. Hafta — Silme, Toplu Aktarım ve Hata Yönetimi

### 16. Gün — Operatör Silme

Anlatılacak konular:

- Silme düğmesi
- `onDeleteOperator`
- Silme öncesi onay penceresi
- Yanlışlıkla silmeyi önleme
- `_deleteOperator`
- `deleteOperator`
- Başarı ve hata mesajları
- Silme sonrası listenin yenilenmesi

Günün çıktısı:

- Onay adımı içeren güvenli silme akışı test edilmiştir.

### 17. Gün — Excel Uyumlu Şablon İndirme

Anlatılacak konular:

- `onDownloadTemplate`
- Excel XML içeriği
- Şablondaki kolonlar:
  - Sicil No
  - Ad
  - Soyad
  - Şifre
- `Blob` kullanımı
- Geçici URL oluşturulması
- Tarayıcı üzerinden dosya indirme
- Şablon dosyasının adı

Günün çıktısı:

- Toplu veri aktarımı için kullanılacak şablon oluşturulmuştur.

### 18. Gün — İçe Aktarma Penceresi

Anlatılacak konular:

- `ImportDialog.fragment.xml`
- `FileUploader`
- Kabul edilen CSV ve XLS dosyaları
- Dosya kolonlarının kullanıcıya açıklanması
- Aktarım özeti
- Hata tablosu
- Satır numarası ve hata açıklaması
- İçe aktarma penceresinin kapatılması

Günün çıktısı:

- Kullanıcının dosya seçip aktarım sonucunu görebileceği arayüz incelenmiştir.

### 19. Gün — CSV ve XLS Dosyalarını Okuma

Anlatılacak konular:

- `onImportFileChange`
- Dosya seçilmemesi durumu
- Dosya uzantısı kontrolü
- `FileReader`
- CSV satırlarının okunması
- Sekme ve noktalı virgül ayraçları
- Excel uyumlu XML okuma
- HTML tablo biçimine alternatif okuma
- Başlık satırının atlanması
- Boş satırların atlanması
- Hücrelerin operatör alanlarına dönüştürülmesi

Günün çıktısı:

- CSV ve XLS verilerinin operatör nesnelerine dönüştürülmesi açıklanmıştır.

### 20. Gün — Toplu Aktarım ve Satır Bazlı Hatalar

Anlatılacak konular:

- `DataService.importOperators`
- Her satır için zorunlu alan kontrolü
- Sicil numarası tekrar kontrolü
- Toplam satır sayısı
- Başarılı kayıt sayısı
- Hatalı kayıt sayısı
- Satır numarasıyla hata gösterme
- Aktarım özetinin arayüzde gösterilmesi
- Aktarım sonrası listenin yenilenmesi

Günün çıktısı:

- Toplu veri aktarımı ve ayrıntılı hata raporlama test edilmiştir.

---

## 5. Hafta — Test, Güvenlik ve Dokümantasyon

### 21. Gün — Veri Servisi Yapısının İncelenmesi

Anlatılacak konular:

- Bellekte tutulan örnek operatör listesi
- `searchOperators`
- `getOperator`
- `saveOperator`
- `deleteOperator`
- `getPassword`
- `getTemplateColumns`
- `importOperators`
- Dönen verilerin kopyalanması
- Prototip servis ile gerçek üretim backend'i arasındaki fark

Günün çıktısı:

- Mevcut veri servisinin sınırları belirlenmiştir.

### 22. Gün — Hata ve Mesaj Yönetimi

Anlatılacak konular:

- `try/catch` yapısı
- Liste yükleme hatası
- Kayıt hatası
- Silme hatası
- Şifre yükleme hatası
- `MessageBox`
- `MessageToast`
- Kullanıcıya anlamlı hata gösterme
- `finally` bloğunda busy durumunu temizleme

Günün çıktısı:

- Başarı ve hata bildirimleri incelenmiştir.

### 23. Gün — Fonksiyonel Test Senaryoları

Raporda aşağıdaki test senaryoları tablo olarak kullanılabilir:

| Test | Senaryo | Beklenen sonuç |
|---:|---|---|
| 1 | Ekranı açma | Operatör listesi görüntülenir |
| 2 | Sicil numarasıyla filtreleme | Uygun kayıtlar gösterilir |
| 3 | Adla filtreleme | Uygun kayıtlar gösterilir |
| 4 | Soyadla filtreleme | Uygun kayıtlar gösterilir |
| 5 | Aktif kayıtları filtreleme | Yalnızca aktif kayıtlar gösterilir |
| 6 | Filtreleri temizleme | Varsayılan filtreler geri gelir |
| 7 | Geçerli operatör ekleme | Yeni kayıt eklenir |
| 8 | Sicil numarasını boş bırakma | Doğrulama hatası gösterilir |
| 9 | Adı boş bırakma | Doğrulama hatası gösterilir |
| 10 | Soyadı boş bırakma | Doğrulama hatası gösterilir |
| 11 | Şifreyi boş bırakma | Doğrulama hatası gösterilir |
| 12 | Aynı sicil numarasını ekleme | Kayıt reddedilir |
| 13 | Mevcut kaydı düzenleme | Bilgiler güncellenir |
| 14 | Kayıt silme | Onaydan sonra kayıt silinir |
| 15 | Silmeyi iptal etme | Kayıt silinmez |
| 16 | Şifreyi gösterme | Şifre görünür |
| 17 | Şifreyi gizleme | Şifre maskelenir |
| 18 | Şablon indirme | Dosya indirilir |
| 19 | Geçersiz dosya seçme | Hata mesajı gösterilir |
| 20 | Geçerli CSV aktarma | Uygun kayıtlar eklenir |
| 21 | Eksik alanlı dosya aktarma | Satır hatası gösterilir |
| 22 | Tekrarlı sicil numarası aktarma | Satır hatası gösterilir |
| 23 | Listeyi yenileme | Liste yeniden yüklenir |

Günün çıktısı:

- Temel fonksiyonlar için test senaryoları hazırlanmıştır.

### 24. Gün — Katmanlar Arası Entegrasyon Testleri

Anlatılacak konular:

- View ile controller bağlantısı
- Controller ile DataService bağlantısı
- Form verisinin servise aktarılması
- Servis sonucunun tabloya yansıması
- Dosya aktarım sonucunun dialoga yansıması
- Hataların doğru bileşende gösterilmesi
- Dialog açma ve kapatma
- Liste yenileme akışı

Günün çıktısı:

- Kullanıcı aksiyonları ve katmanlar arası veri akışı kontrol edilmiştir.

### 25. Gün — Kullanılabilirlik ve Görsel Testler

Anlatılacak konular:

- Form alanlarının anlaşılabilirliği
- Butonların konumu ve işlevi
- Hata mesajlarının görünürlüğü
- Tablo kolonlarının okunabilirliği
- Dosya aktarım sonucunun anlaşılabilirliği
- Şifre düğmesinin kullanımı
- Masaüstü, tablet ve telefon desteği
- Busy durumunda butonların pasifleşmesi

Günün çıktısı:

- Kullanıcı deneyimi ve görsel kullanım açısından kontroller yapılmıştır.

### 26. Gün — Güvenlik ve Veri Koruma

Anlatılacak konular:

- Şifrelerin tabloda maskeli gösterilmesi
- Şifre görüntülemenin kullanıcı aksiyonuyla yapılması
- Düz metin şifre tutmanın riski
- Gerçek sistemde hash kullanılması gereği
- Şifre görüntüleme için yetki kontrolü ihtiyacı
- Dosya içeriği ve dosya güvenliği
- Kişisel verilerin korunması
- Rapor içinde gerçek kullanıcı bilgilerinin paylaşılmaması

Önemli not:

- Kodda açık bir rol veya yetki kontrolü bulunmuyorsa raporda yapılmış gibi anlatılmamalıdır.
- Yetkilendirme, gelecekte yapılabilecek geliştirme olarak açıklanmalıdır.

### 27. Gün — Gerçek Backend Entegrasyonu İçin Öneriler

Anlatılacak konular:

- Bellekte tutulan örnek verinin sınırlılıkları
- Kalıcı veri saklama gereksinimi
- Gerçek backend servisinin gerekliliği
- Listeleme, ekleme, güncelleme ve silme işlemlerinin backend üzerinden yürütülmesi
- Backend tarafında doğrulama
- Benzersiz sicil numarası kontrolü
- Şifrelerin güvenli saklanması
- Servis hatalarının kullanıcı dostu mesajlara dönüştürülmesi

Bu bölümde:

- Gerçek endpoint, tablo veya HTTP metodu uydurulmamalıdır.
- Konu “gelecekte yapılabilecek geliştirme” olarak yazılmalıdır.

### 28. Gün — Teknik Dokümantasyon ve Kullanıcı Kılavuzu

Anlatılacak konular:

- Ekranın amacı
- Filtre alanlarının kullanımı
- Yeni operatör ekleme
- Operatör düzenleme
- Operatör silme
- Şifre görüntüleme
- Şablon indirme
- CSV/XLS dosyası aktarma
- Aktarım hatalarını yorumlama
- Aktif ve pasif durumların anlamı
- Hata mesajları ve çözüm yolları

Günün çıktısı:

- Teknik açıklamalar ve son kullanıcı kullanım adımları hazırlanmıştır.

### 29. Gün — Son Kontroller ve Hata Düzeltmeleri

Anlatılacak konular:

- Test sonuçlarının değerlendirilmesi
- Hataların önem derecesine göre sınıflandırılması
- Form doğrulamalarının tekrar kontrolü
- Filtreleme sonuçlarının kontrolü
- Toplu aktarımın tekrar test edilmesi
- Mesajların kontrolü
- Kod okunabilirliği
- Gereksiz kodların gözden geçirilmesi

Günün çıktısı:

- Son hata listesi ve düzeltme sonuçları hazırlanmıştır.

### 30. Gün — Genel Değerlendirme ve Raporun Tamamlanması

Anlatılacak konular:

- 30 günlük çalışmanın özeti
- Proje hedefleri ve gerçekleşen çalışmalar
- Öğrenilen teknolojiler
- Karşılaşılan teknik sorunlar
- Sorun çözme yöntemleri
- Projenin sınırlılıkları
- Gelecekte yapılabilecek geliştirmeler
- Teknik ve kişisel kazanımlar
- İngilizce staj raporunun son hâle getirilmesi

Günün çıktısı:

- İngilizce staj raporu tamamlanmış ve teslim formatına hazırlanmıştır.

---

# 4. Teknik Rapor Bölümleri

Yapay zekâ, günlük çalışma planına ek olarak aşağıdaki teknik bölümleri de İngilizce hazırlamalıdır.

## 4.1 Introduction

Açıklanacak konular:

- Internship purpose
- Project purpose
- MES systems in manufacturing
- Importance of operator master data
- Project scope

## 4.2 Technologies Used

Açıklanacak teknolojiler:

- JavaScript
- SAPUI5
- XML View
- MVC architecture
- `JSONModel`
- `Fragment`
- `DataService`
- HTML5 File API
- `FileReader`
- `Blob`
- XML and CSV parsing
- Git, yalnızca gerçekten kullanıldıysa

## 4.3 System Architecture

Aşağıdaki akış İngilizce açıklanmalıdır:

```text
User
  ↓
Main.view.xml
  ↓
Main.controller.js
  ↓
model/models.js
  ↓
model/DataService.js
  ↓
Operator data
```

Açıklamada:

- View katmanının kullanıcı arayüzünü oluşturduğu
- Controller katmanının kullanıcı aksiyonlarını yönettiği
- View modelin ekran durumunu tuttuğu
- DataService katmanının veri işlemlerini gerçekleştirdiği
- Mevcut DataService yapısının örnek verileri bellekte tuttuğu

belirtilmelidir.

## 4.4 Screen Design

Açıklanacak alanlar:

- Filter panel
- Operator table
- Action buttons
- Add/edit dialog
- Import dialog
- Import error table
- Header component

## 4.5 Data Model

Kodda bulunan operatör alanları:

| Alan | Açıklama |
|---|---|
| `personnelNo` | Operatör sicil numarası |
| `firstName` | Operatör adı |
| `lastName` | Operatör soyadı |
| `status` | Operatör durumu |
| `password` | Operatör şifresi |
| `createdAt` | Kayıt oluşturulma zamanı |
| `updatedAt` | Kayıt güncellenme zamanı |

Liste gösteriminde kullanılan ek alanlar:

| Alan | Açıklama |
|---|---|
| `passwordMasked` | Maskeli şifre |
| `passwordVisible` | Şifre görünürlük durumu |
| `passwordValue` | Görüntülenen şifre değeri |

## 4.6 User Actions and Code Flow

| Kullanıcı işlemi | Kontrolcü fonksiyonu | Veri işlemi |
|---|---|---|
| Filtre uygula | `onApplyFilters` | `searchOperators` |
| Filtreleri temizle | `onClearFilters` | Varsayılan filtreleri ayarlar ve listeyi yükler |
| Listeyi yenile | `onRefresh` | `searchOperators` |
| Yeni operatör ekle | `onAddOperator` | Formu açar |
| Operatör düzenle | `onEditOperator` | `getOperator`, sonra `saveOperator` |
| Operatör kaydet | `onSaveOperator` | `saveOperator` |
| Operatör sil | `onDeleteOperator`, `_deleteOperator` | `deleteOperator` |
| Şifreyi göster/gizle | `onToggleRowPassword` | `getPassword` |
| Şablon indir | `onDownloadTemplate` | Tarayıcıda XLS dosyası oluşturur |
| Dosya aktar | `onImportFileChange` | `importOperators` |

## 4.7 Validation Rules

Raporda şu kurallar açıklanmalıdır:

- Personnel number cannot be empty.
- First name cannot be empty.
- Last name cannot be empty.
- Password cannot be empty.
- Duplicate personnel numbers cannot be added.
- Required fields are checked during file import.
- Only CSV and XLS files are accepted.
- Personnel number cannot be changed during editing.

## 4.8 Error and Message Handling

Açıklanacak konular:

- Loading errors
- Save errors
- Delete errors
- Password-loading errors
- Invalid file-format errors
- Row-level import errors
- Duplicate personnel number errors
- Success messages
- Import summary
- `MessageBox`
- `MessageToast`
- `try/catch/finally` kullanımı

## 4.9 Testing

Test başlıkları:

- Functional tests
- Form validation tests
- Filtering tests
- CRUD tests
- Password visibility tests
- File-import tests
- Error-handling tests
- Usability tests
- Responsive layout tests
- Integration-flow tests

## 4.10 Project Limitations

Koddan doğrulanabilen sınırlılıklar:

- `DataService.js` verileri bellekte tutmaktadır.
- Veriler gerçek ve kalıcı bir veritabanına yazılmamaktadır.
- Sayfa yenilendiğinde prototip veri yapısı kalıcılık sağlamaz.
- Bu ekran dosyalarında gerçek backend endpoint bilgisi bulunmamaktadır.
- Açık bir kullanıcı rolü veya yetkilendirme akışı görülmemektedir.
- Örnek servis içinde şifreler düz metin olarak tutulmaktadır.
- Üretim ortamı için backend doğrulaması ve güvenli şifre saklama gereklidir.

## 4.11 Future Improvements

Aşağıdaki maddeler yapılmış gibi değil, öneri olarak anlatılmalıdır:

- Kalıcı veritabanı entegrasyonu
- Gerçek backend API entegrasyonu
- Rol ve yetki kontrolü
- Şifrelerin hashlenerek saklanması
- Şifre görüntüleme için ek yetki kontrolü
- Dosya boyutu ve içerik güvenliği kontrolü
- Tarih aralığı filtreleri
- Sayfalama
- Sıralama
- Dışa aktarma
- İşlem kayıtlarının tutulması
- Otomatik testler
- Ayrıntılı servis hata kodları
- Erişilebilirlik geliştirmeleri

---

# 5. İngilizce Sonuç Bölümü İçin Ana Fikirler

Yapay zekâ sonuç bölümünde aşağıdaki fikirleri İngilizce olarak açıklamalıdır:

- SAPUI5 tabanlı bir web ekranının yapısı incelenmiştir.
- MVC mimarisinin uygulamadaki kullanımı öğrenilmiştir.
- XML View ile kullanıcı arayüzü oluşturulmuştur.
- JavaScript controller ile kullanıcı aksiyonları yönetilmiştir.
- JSONModel ile ekran durumu ve form verileri tutulmuştur.
- Listeleme, filtreleme, ekleme, güncelleme ve silme işlemleri incelenmiştir.
- Form doğrulama ve hata yönetimi uygulanmıştır.
- CSV ve XLS dosyalarından toplu veri aktarımı gerçekleştirilmiştir.
- Kullanıcı deneyimi ve veri güvenliği değerlendirilmiştir.
- Mevcut DataService yapısının prototip niteliğinde olduğu görülmüştür.
- Yazılım geliştirme sürecinde analiz, uygulama, test ve dokümantasyonun birlikte yürütülmesi gerektiği öğrenilmiştir.

---

# 6. Gerçeklik Kontrol Listesi

Rapor oluşturulmadan önce aşağıdaki kontroller yapılmalıdır:

- [ ] Nihai rapor tamamen İngilizce yazıldı.
- [ ] Kodda olmayan API adresi eklenmedi.
- [ ] Kodda olmayan veritabanı tablosu eklenmedi.
- [ ] Kodda olmayan kullanıcı rolü eklenmedi.
- [ ] Gerçekleştirilmemiş backend entegrasyonu yapılmış gibi anlatılmadı.
- [ ] Örnek şifreler rapora yazılmadı.
- [ ] Kişisel bilgiler rapora yazılmadı.
- [ ] `DataService.js` prototip ve bellekte çalışan servis olarak açıklandı.
- [ ] Mevcut özelliklerle önerilen özellikler ayrıldı.
- [ ] Her gün için farklı çalışma anlatıldı.
- [ ] Toplam süre 30 gün ve 240 saat olarak korundu.
- [ ] Test senaryoları ve beklenen sonuçları belirtildi.
- [ ] Proje sınırlılıkları açıklandı.
- [ ] Kaynak dosyalar teknik bölümlerde doğru kullanıldı.

---

# 7. Saat Dağılımı

| Çalışma alanı | Saat |
|---|---:|
| Proje ve gereksinim analizi | 24 |
| Proje yapısı ve SAPUI5 MVC incelemesi | 24 |
| Arayüz ve görünüm geliştirme | 24 |
| Görünüm modeli ve listeleme | 16 |
| Filtreleme ve yenileme | 16 |
| Operatör ekleme ve form doğrulama | 24 |
| Operatör düzenleme ve silme | 24 |
| Şifre görünürlüğü ve veri güvenliği değerlendirmesi | 16 |
| Şablon indirme ve toplu veri aktarımı | 32 |
| Hata yönetimi ve kullanılabilirlik | 16 |
| Testler ve hata düzeltmeleri | 16 |
| Teknik dokümantasyon ve İngilizce staj raporu | 8 |
| **Toplam** | **240** |

---

# 8. Nihai İngilizce Raporun Teslim Yapısı

Yapay zekâ tarafından hazırlanacak nihai rapor İngilizce olarak şu yapıda olmalıdır:

1. Cover Page
2. Preface
3. Table of Contents
4. Company and Working Environment
5. Technologies Used
6. Project Purpose and Scope
7. Requirements Analysis
8. Existing Project Structure
9. SAPUI5 MVC Architecture
10. Screen Design
11. View Model
12. Operator Listing and Filtering
13. Operator Creation and Editing
14. Operator Deletion
15. Password Visibility and Security
16. File Template and Bulk Import
17. Data Validation
18. Error Handling
19. Testing Activities
20. Thirty-Day Internship Log
21. Problems and Solutions
22. Project Limitations
23. Future Improvements
24. Technical and Personal Achievements
25. Conclusion
26. References
27. Appendices

## Eklerde Bulunabilecekler

- Ekran görüntüleri
- Kullanıcı akış şeması
- Proje dosya yapısı
- Test senaryoları
- Örnek CSV/XLS şablonu
- Veri modeli şeması
- Kısa ve güvenli kod parçaları
- Günlük çalışma çizelgesi

> Kod parçaları rapora eklenirken şifre, token, bağlantı bilgisi veya kişisel veri kullanılmamalıdır.
