# MES022 – Operatör Anaveri Ekleme / Güncelleme Ekranı

## Doküman amacı

Bu doküman, paylaşılan Functional Specification (FS) içeriğine göre MES022 ekranının fonksiyonel ve teknik ekran tasarımını tanımlar.

Tasarım kararı:

- Operatör şifresi FS gereksinimi olarak korunur.
- Şifre ana liste/grid ekranında kolon olarak gösterilmez.
- Şifre yalnızca yeni operatör ekleme ve operatör güncelleme popup'ında bulunur.
- Şifre ana liste, filtre alanları ve liste sonuçlarında gösterilmez.
- Şifre ile ilgili login, authentication veya giriş doğrulama fonksiyonu bu tasarımın kapsamına dahil değildir.
- FS'te açıkça bulunmayan noktalar `FS'te belirtilmemiş` veya `Öneri` etiketiyle ayrıştırılmıştır.

---

# 1. İş Analizi

## 1.1 Ekranın amacı

MES022 ekranının amacı, MES/MII sisteminde kullanılacak operatör anaverisinin bakımını sağlamaktır.

FS'e göre yönetilecek temel bilgiler:

- Sicil numarası
- İsim-soyisim
- Şifre

Sicil numarası operatör kaydının anahtar alanıdır. MII sisteminde operatörlerin vardiya giriş-çıkış takibinin, bu bakım ekranında oluşturulan sicil verileri üzerinden yapılması beklenmektedir.

## 1.2 FS'ten gelen kullanım senaryoları

### Senaryo 1 – Operatör listesini görüntüleme

1. Kullanıcı MES022 ekranını açar.
2. Sistem operatör sicil kayıtlarını listeler.
3. Liste üzerinde sicil no, ad-soyad ve durum bilgisi görüntülenir.
4. Şifre listede gösterilmez.

> Durum alanı, kullanıcının özel grid talebi kapsamında tasarıma eklenmiştir. FS'in operatör alanları listesinde durum ayrıca tanımlanmamıştır.

### Senaryo 2 – Yeni operatör ekleme

1. Kullanıcı `Yeni Operatör Ekle` butonuna basar.
2. Yeni operatör popup'ı açılır.
3. Kullanıcı sicil no, ad, soyad ve şifre bilgilerini girer.
4. Kullanıcı `Kaydet` butonuna basar.
5. Sistem alan doğrulamalarını yapar.
6. Doğrulama başarılıysa yeni operatör kaydı oluşturulur.
7. Popup kapanır ve liste yenilenir.

### Senaryo 3 – Operatör güncelleme

1. Kullanıcı gridde bir operatör seçer.
2. `Güncelle` aksiyonuna basar.
3. Operatör güncelleme popup'ı açılır.
4. Kullanıcı sicil no, ad, soyad ve şifre bilgilerini düzenler.
5. Kullanıcı `Kaydet` butonuna basar.
6. Sistem kaydı günceller.
7. Liste yenilenir.

> Mevcut şifrenin popup açılışında gösterilip gösterilmeyeceği FS'te belirtilmemiştir. Öneri: Mevcut şifre geri okunmamalı; alan boş bırakılmalı ve yalnızca yeni değer girildiğinde güncelleme yapılmalıdır. Bu davranış uygulama güvenlik tasarımı olarak ayrıca onaylanmalıdır.

### Senaryo 4 – Operatör silme

1. Kullanıcı gridde bir operatör seçer.
2. `Sil` aksiyonuna basar.
3. Sistem silme onayı gösterir.
4. Kullanıcı onay verirse kayıt silinir.
5. Liste yenilenir.

FS'te silme işleminin fiziksel mi yoksa pasife alma şeklinde mi yapılacağı belirtilmemiştir.

### Senaryo 5 – Excel şablonu indirme

1. Kullanıcı `Excel Şablonu İndir` butonuna basar.
2. Sistem FS'te belirtilen kolonları içeren Excel şablonunu indirir.
3. Kullanıcı şablonu doldurur.

FS'te belirtilen şablon kolonları:

- Sicil No
- İsim Soyisim
- Şifre

### Senaryo 6 – Excel içe aktarma

1. Kullanıcı `Excel İçe Aktar` butonuna basar.
2. Dosya seçme alanı açılır.
3. Kullanıcı doldurulmuş Excel dosyasını seçer.
4. Sistem satırları doğrular.
5. Geçerli satırlar için operatör kayıtları toplu olarak oluşturulur.
6. Hatalı satırlar kullanıcıya raporlanır.

Hatalı satırların geçerli satırlardan bağımsız kaydedilip kaydedilmeyeceği FS'te belirtilmemiştir.

## 1.3 Kullanıcı rolleri

### FS'ten gelen bilgi

FS'te ekranı kullanacak rol veya rol isimleri açıkça tanımlanmamıştır.

### Öneri

- Operatör anaverisini yönetmeye yetkili MES ana veri kullanıcısı
- Operatör sicil listesini sağlayan MES ekibi

Bu rollerin yetki matrisi ve aksiyon bazlı izinleri FS'te belirtilmemiştir.

## 1.4 İş kuralları

| Kural | Kaynak | Tasarım karşılığı |
|---|---|---|
| Sicil numarası anahtar alandır | FS | Sicil No benzersiz olmalıdır |
| Operatör bilgileri manuel girilebilir | FS | Popup üzerinden kayıt/güncelleme |
| Operatör bilgileri Excel ile toplu girilebilir | FS | Excel içe aktarma |
| Sicil No, İsim Soyisim ve Şifre Excel şablonunda bulunur | FS | Şifre gridde değil, yalnızca Excel şablon/import akışında |
| Mevcut kayıt güncellenebilir | FS | Grid satır aksiyonu ile güncelleme |
| Kayıt silinebilir | FS | Grid satır aksiyonu ile silme |
| Şifre gridde gösterilmez | Tasarım kararı | Grid, filtre ve liste DTO'sunda şifre alanı bulunmaz |
| Durum Aktif/Pasif olarak gösterilir | Kullanıcı tasarım talebi | Grid kolonu ve popup alanı; FS'te alanın kaynağı belirtilmemiştir |
| Oluşturma/Güncelleme tarihi gridde gösterilir | Kullanıcı tasarım talebi | Tarih kolonları; FS'te belirtilmemiştir |

---

# 2. Ekran Alanları

## 2.1 Ana ekran filtre alanları

| Teknik alan adı | Etiket | Veri tipi | Zorunlu | Doğrulama | Açıklama |
|---|---|---|---|---|---|
| `personnelNoFilter` | Sicil No | String | Hayır | Girilmişse sicil no ile eşleşme | FS'te ayrı filtre alanı belirtilmemiştir; Öneri |
| `fullNameFilter` | Ad Soyad | String | Hayır | Girilmişse metin araması | FS'te belirtilmemiştir; Öneri |
| `statusFilter` | Durum | Enum | Hayır | `ACTIVE` veya `PASSIVE` | Durum kolonu tasarım talebidir; filtre Öneridir |
| `createdAtFrom` | Oluşturma Tarihi Başlangıç | Date | Hayır | Geçerli tarih | Öneri |
| `createdAtTo` | Oluşturma Tarihi Bitiş | Date | Hayır | Başlangıçtan küçük olamaz | Öneri |
| `updatedAtFrom` | Güncelleme Tarihi Başlangıç | Date | Hayır | Geçerli tarih | Öneri |
| `updatedAtTo` | Güncelleme Tarihi Bitiş | Date | Hayır | Başlangıçtan küçük olamaz | Öneri |

Şifre için filtre alanı oluşturulmaz.

## 2.2 Yeni/Güncelle popup alanları

| Teknik alan adı | Etiket | Veri tipi | Zorunlu | Doğrulama | Açıklama |
|---|---|---|---|---|---|
| `personnelNo` | Sicil No | String | Evet | Boş olamaz; kayıt eklemede benzersiz olmalıdır | FS'teki key alan |
| `firstName` | Ad | String | Evet | Boş olamaz | FS'teki isim bilgisinin ayrıştırılmış tasarımı |
| `lastName` | Soyad | String | Evet | Boş olamaz | FS'teki isim bilgisinin ayrıştırılmış tasarımı |
| `password` | Şifre | Password/String | Evet* | Boş olamaz; uzunluk/karakter kuralı FS'te belirtilmemiştir | Yalnızca popup'ta gösterilir |
| `status` | Durum | Enum | Evet* | `Aktif` veya `Pasif` | Grid talebine göre eklenmiştir; FS'te form alanı olarak belirtilmemiştir |
| `createdAt` | Oluşturma Tarihi | DateTime | Hayır | Sistem tarafından atanır | Kullanıcı talebine göre gridde gösterilir; popup'ta gösterilmesi Öneri değildir |
| `updatedAt` | Güncelleme Tarihi | DateTime | Hayır | Sistem tarafından atanır | Kullanıcı talebine göre gridde gösterilir |

`password` alanının güncelleme işleminde zorunlu olup olmadığı FS'te belirtilmemiştir.

Öneri:

- Yeni kayıtta zorunlu olsun.
- Güncellemede boş bırakılırsa mevcut değer korunabilsin.
- Mevcut değer popup'ta açık veya maskeli şekilde geri gösterilmesin.
- Şifrenin saklama/şifreleme yöntemi backend güvenlik tasarımıyla belirlenmelidir; FS'te belirtilmemiştir.

## 2.3 Birleştirilmiş ad-soyad yaklaşımı

FS, `İsim Soyisim` bilgisini birlikte ifade eder. Kullanıcı talebi ise gridde `Ad Soyad` gösterilmesini istemektedir.

Öneri:

- Popup'ta kullanılabilirlik için `Ad` ve `Soyad` ayrı alanlar kullanılır.
- Gridde `firstName + ' ' + lastName` birleştirilerek `Ad Soyad` gösterilir.
- Excel şablonunda FS'e sadık kalınarak tek `İsim Soyisim` kolonu bulunur.
- Excel import sırasında isim-soyadın ayrıştırılması gerekiyorsa kural FS'te belirtilmemiştir ve ayrıca netleştirilmelidir.

Daha düşük kapsam riski taşıyan alternatif:

- Popup'ta tek `fullName` alanı kullanılır.
- Teknik veri modelinde `fullName` tutulur.
- Bu alternatifte Ad/Soyad ayrıştırma yapılmaz.

---

# 3. Grid Tasarımı

## 3.1 Ana grid kolonları

| Sıra | Teknik alan | Kolon başlığı | Veri tipi | Görünürlük | Açıklama |
|---:|---|---|---|---|---|
| 1 | `personnelNo` | Sicil No | String | Görünür | Anahtar alan |
| 2 | `fullName` | Ad Soyad | String | Görünür | Ad ve soyadın birleşik gösterimi |
| 3 | `status` | Durum | Enum | Görünür | Aktif/Pasif |
| 4 | `createdAt` | Oluşturma Tarihi | DateTime | Görünür | Öneri; FS'te belirtilmemiştir |
| 5 | `updatedAt` | Güncelleme Tarihi | DateTime | Görünür | Öneri; FS'te belirtilmemiştir |
| 6 | `actions` | İşlemler | Action | Görünür | Güncelle/Sil aksiyonları |

Gridde `password` veya herhangi bir şifre maskesi kolonu bulunmaz.

## 3.2 Grid özellikleri

### FS'ten gelen

- Operatör sicil kayıtları listelenmelidir.
- Sicil No, isim-soyisim bilgisi listelenmelidir.
- Şifre listede gösterilmemelidir.

### Öneri

- Kolon bazlı sıralama: Sicil No, Ad Soyad, Oluşturma Tarihi, Güncelleme Tarihi
- Filtreleme: Sicil No, Ad Soyad, Durum, tarih aralıkları
- Sayfalama
- Boş liste durumu
- Satır seçimi
- Satır aksiyonları
- Durum için renkli gösterim:
  - Aktif: yeşil durum etiketi
  - Pasif: gri/kırmızı durum etiketi

Sayfalama, sıralama ve kolon görünürlük yönetimi FS'te belirtilmemiştir.

## 3.3 Grid aksiyonları

- `Güncelle`: Seçili kaydın popup'ını açar.
- `Sil`: Silme onay popup'ını açar.
- `Yeni Operatör Ekle`: Form popup'ını boş açar.
- `Excel Şablonu İndir`: FS'teki Excel kolonlarını indirir.
- `Excel İçe Aktar`: Excel dosyası seçme akışını açar.

`Şifre Sıfırla` veya `Şifre Güncelle` ayrı aksiyonu:

- FS'te ayrı aksiyon olarak belirtilmemiştir.
- Popup içinde şifre alanı zaten bulunacağından ek aksiyon önerilmemektedir.
- Ayrı aksiyon istenirse `Öneri` olarak değerlendirilmelidir.

---

# 4. CRUD İşlemleri

## 4.1 Yeni Operatör Ekle

### Kullanıcı akışı

1. Kullanıcı `Yeni Operatör Ekle` butonuna basar.
2. Modal popup açılır.
3. Popup başlığı `Yeni Operatör Ekle` olur.
4. Kullanıcı Sicil No, Ad, Soyad, Şifre ve gerekiyorsa Durum girer.
5. Kullanıcı `Kaydet` butonuna basar.
6. Frontend zorunlu alan ve biçim kontrollerini yapar.
7. Backend sicil no tekrarını kontrol eder.
8. Başarılıysa kayıt oluşturulur.
9. Başarı mesajı gösterilir.
10. Popup kapanır ve grid yenilenir.

### Hata durumları

- Sicil No boş: `Sicil No alanı zorunludur.`
- Ad boş: `Ad alanı zorunludur.`
- Soyad boş: `Soyad alanı zorunludur.`
- Şifre boş: `Şifre alanı zorunludur.`
- Sicil No mevcut: `Bu Sicil No ile kayıtlı bir operatör bulunmaktadır.`
- Servis hatası: `Operatör kaydı oluşturulamadı.`

Mesaj metinleri FS'te verilmemiştir; öneri niteliğindedir.

## 4.2 Güncelle

### Kullanıcı akışı

1. Kullanıcı grid satırındaki `Güncelle` aksiyonuna basar.
2. Popup mevcut operatör bilgileriyle açılır.
3. Sicil No anahtar alan olduğu için güncellemede salt okunur gösterilmesi Öneridir.
4. Ad ve Soyad düzenlenebilir.
5. Şifre alanı popup'ta gösterilir; mevcut şifre değeri FS'te tanımlanmamıştır.
6. Kullanıcı `Kaydet` butonuna basar.
7. Sistem doğrulama yapar.
8. Backend güncelleme işlemini gerçekleştirir.
9. Grid yenilenir.

### Önerilen şifre davranışı

- Şifre alanı `type=password` olarak gösterilir.
- Mevcut şifre değeri frontend'e geri gönderilmez.
- Alan boş bırakılırsa mevcut şifre korunur.
- Yeni değer girilirse şifre güncellenir.
- Bu davranış FS'te belirtilmemiş güvenlik önerisidir.

## 4.3 Sil

### Kullanıcı akışı

1. Kullanıcı bir kaydın `Sil` aksiyonuna basar.
2. Onay popup'ı açılır.
3. Popup sicil no ve ad-soyad bilgisini gösterir.
4. Şifre gösterilmez.
5. Kullanıcı `Vazgeç` veya `Sil` seçer.
6. Onay verilirse backend silme isteği gönderilir.
7. Başarı halinde grid yenilenir.

### Silme türü

- FS silme işleminin yapılabileceğini belirtir.
- Fiziksel silme veya pasif yapma yöntemi FS'te belirtilmemiştir.
- Öneri: Vardiya geçmişi ile ilişkili kayıtların korunması gerekiyorsa pasife alma tercih edilebilir. Bu karar iş sahibi tarafından onaylanmalıdır.

## 4.4 Toplu Veri Yükleme

Toplu veri yükleme FS'te Excel import yöntemiyle tanımlanmıştır.

### Kullanıcı akışı

1. Kullanıcı `Excel İçe Aktar` butonuna basar.
2. Dosya seçim popup'ı açılır.
3. Kullanıcı `.xlsx` dosyası seçer.
4. Sistem dosya yapısını kontrol eder.
5. Satır bazında validasyon yapılır.
6. Geçerli ve hatalı satır sayısı gösterilir.
7. Kullanıcı yüklemeyi onaylar.
8. Sistem kayıtları toplu olarak kaydeder.
9. Sonuç özeti gösterilir.

Toplu yükleme ön izleme ekranının bulunması FS'te belirtilmemiştir; Öneridir.

## 4.5 Excel Şablonu İndir

### FS'ten gelen kolonlar

| Excel kolon başlığı | Teknik karşılık | Açıklama |
|---|---|---|
| Sicil No | `personnelNo` | Operatör anahtar alanı |
| İsim Soyisim | `fullName` | Operatör ad-soyad bilgisi |
| Şifre | `password` | Operatör şifre bilgisi; gridde gösterilmez |

Şablonda şifre kolonu bulunur; çünkü FS bu kolonu açıkça tanımlamaktadır.

### Öneri

- İlk satır kolon başlıkları olsun.
- İkinci satırdan itibaren veri girişi yapılsın.
- Dosya `.xlsx` formatında indirilsin.
- Şablon dosyasında örnek veri bulunmasın.
- Şifre kolonunda değer maskelemesi yapılmasın; ancak Excel dosyasının güvenli paylaşımı kullanıcı sorumluluğundadır. Bu güvenlik prosedürü FS'te belirtilmemiştir.

## 4.6 Excel İçe Aktar

### Kullanıcı akışı

1. `Excel İçe Aktar` butonuna basılır.
2. Dosya seçilir.
3. Dosya uzantısı kontrol edilir.
4. Kolon başlıkları kontrol edilir.
5. Veri satırları okunur.
6. Validasyon sonuçları gösterilir.
7. Kullanıcı yüklemeyi onaylar.
8. Geçerli satırlar kaydedilir.
9. Hatalı satırlar hata nedeni ile raporlanır.

---

# 5. UI/UX Tasarımı

## 5.1 Sayfa yerleşimi

1. Sayfa başlığı
2. Filtre alanı
3. İşlem butonları
4. Operatör grid'i
5. Liste durum mesajı / toplam kayıt bilgisi

### Sayfa başlığı

`MES022 – Operatör Anaveri Ekleme / Güncelleme`

Klasör adı:

`MES/WEB/Operatör anaveri ekleme ekranı`

## 5.2 Filtre alanı

Önerilen filtre satırı:

- Sicil No
- Ad Soyad
- Durum
- Oluşturma Tarihi
- Güncelleme Tarihi
- `Filtrele`
- `Temizle`

Şifre filtresi yoktur.

Filtreleme alanlarının tamamı FS'te açıkça tanımlanmadığı için öneridir.

## 5.3 Butonlar

| Buton | Kaynak | İşlev |
|---|---|---|
| Yeni Operatör Ekle | FS | Yeni kayıt popup'ını açar |
| Excel Şablonu İndir | FS | Şablon dosyasını indirir |
| Excel İçe Aktar | FS | Toplu Excel yükleme sürecini başlatır |
| Filtrele | Öneri | Grid verisini filtreler |
| Temizle | Öneri | Filtre alanlarını temizler |
| Güncelle | FS | Seçili kaydı günceller |
| Sil | FS | Seçili kaydı siler |

## 5.4 Yeni/Güncelle popup

Popup bölümleri:

### Operatör bilgileri

- Sicil No
- Ad
- Soyad
- Durum

### Şifre

- Şifre
- Şifre alanı maskeli gösterim
- Güncellemede mevcut değerin geri gösterilmemesi önerilir

Şifre popup'ta görünür; gridde görünmez.

### Popup butonları

- Kaydet
- İptal

`Şifreyi Göster` ikonunun kullanılması FS'te belirtilmemiştir. Güvenlik nedeniyle varsayılan tasarıma eklenmemiştir.

## 5.5 Excel import popup

Önerilen içerik:

- Dosya seçme alanı
- Kabul edilen format bilgisi: `.xlsx`
- Şablon kolonları hakkında açıklama
- Dosya adı
- Satır sayısı
- Hatalı/geçerli satır özeti
- `Yükle`
- `İptal`

Dosya boyutu, maksimum satır sayısı ve tekrar yükleme davranışı FS'te belirtilmemiştir.

## 5.6 Hata mesajları

Önerilen mesajlar:

- `Lütfen zorunlu alanları doldurunuz.`
- `Sicil No alanı boş bırakılamaz.`
- `Bu Sicil No zaten kayıtlıdır.`
- `Seçilen dosyanın formatı desteklenmiyor.`
- `Excel kolonları beklenen formatta değil.`
- `Excel dosyasında veri bulunamadı.`
- `Satır doğrulaması başarısız.`
- `Operatör kaydı silinemedi.`
- `Operatör kaydı güncellenemedi.`
- `Operatör kaydı oluşturulamadı.`

Hata metinleri ve hata kodları FS'te belirtilmemiştir.

## 5.7 Başarı mesajları

Önerilen mesajlar:

- `Operatör başarıyla oluşturuldu.`
- `Operatör başarıyla güncellendi.`
- `Operatör başarıyla silindi.`
- `Excel içe aktarma tamamlandı.`
- `Excel içe aktarma tamamlandı. Başarılı: {n}, Hatalı: {m}.`

---

# 6. Excel Entegrasyonu

## 6.1 Şablon kolonları

FS'e göre:

1. `Sicil No`
2. `İsim Soyisim`
3. `Şifre`

Şifre, Excel şablonunda yer alır; ana gridde yer almaz.

## 6.2 Import validasyonları

### FS'ten doğrudan çıkarılabilen kontroller

- Sicil No bilgisi alınabilmelidir.
- İsim Soyisim bilgisi alınabilmelidir.
- Şifre bilgisi alınabilmelidir.
- Kayıtlar toplu olarak sisteme eklenebilmelidir.

### Önerilen kontroller

| Kontrol | Sonuç |
|---|---|
| Dosya uzantısı `.xlsx` mi? | Değilse dosya reddedilir |
| Beklenen kolonlar var mı? | Eksikse import reddedilir |
| Sicil No boş mu? | Satır hatalı |
| İsim Soyisim boş mu? | Satır hatalı |
| Şifre boş mu? | Satır hatalı |
| Sicil No formatı geçerli mi? | Kural FS'te belirtilmemiş; proje kararı gerekir |
| Aynı dosyada sicil no tekrarı var mı? | Satır hatalı veya tekrar kaydı güncelleme; FS'te belirtilmemiş |
| Sistemde sicil no mevcut mu? | Ekleme/güncelleme davranışı FS'te belirtilmemiş |
| Fazladan kolon var mı? | Uyarı veya hata davranışı FS'te belirtilmemiş |

## 6.3 Ad-soyad işleme

FS'teki Excel kolonu `İsim Soyisim` şeklindedir.

Ad ve soyadın ayrıştırılması:

- Birden fazla boşluk içeren isimlerde ayrıştırma kuralı FS'te belirtilmemiştir.
- Tek `fullName` olarak saklama veya ilk kelimeyi ad, kalanını soyad kabul etme seçenekleri vardır.
- Öneri: FS netleştirilene kadar `İsim Soyisim` tek metin olarak alınsın ve veri modelinde `fullName` alanı kullanılsın.

## 6.4 Hatalı satır yönetimi

### Önerilen sonuç ekranı

| Satır No | Sicil No | İsim Soyisim | Sonuç | Hata Açıklaması |
|---:|---|---|---|---|
| 2 | 10001 | Ali Yılmaz | Başarılı | - |
| 3 | - | Ayşe Kaya | Hatalı | Sicil No boş |
| 4 | 10003 | Mehmet Demir | Hatalı | Sicil No zaten mevcut |

### Kayıt stratejisi

FS'te belirtilmemiştir:

- Tamamı başarılıysa toplu commit
- Geçerli satırları kaydet, hatalıları atla
- Herhangi bir hata varsa tüm importu iptal et

Öneri: Kullanıcıya geçerli/hatalı satır özeti gösterilmeli; kayıt stratejisi iş sahibi ve backend tasarımıyla netleştirilmelidir.

---

# 7. Teknik Tasarım

## 7.1 Frontend sayfa yapısı

Klasör:

`MES/WEB/Operatör anaveri ekleme ekranı`

Önerilen SAPUI5 uygulama yapısı:

```text
Operatör anaveri ekleme ekranı/
├── Component.js
├── index.html
├── manifest.json
├── controller/
│   └── Main.controller.js
├── view/
│   ├── Main.view.xml
│   └── fragments/
│       ├── OperatorDialog.fragment.xml
│       ├── DeleteConfirm.fragment.xml
│       └── ImportDialog.fragment.xml
├── model/
│   └── formatter.js
├── i18n/
│   └── i18n.properties
└── css/
    └── style.css
```

Bu klasör ve dosya isimleri tasarım/uygulama önerisidir; FS'te belirtilmemiştir.

## 7.2 Backend API ihtiyaçları

Aşağıdaki servisler ekranın FS'te belirtilen işlevlerini desteklemek için gereklidir:

### Listeleme

```http
GET /api/operators
```

Önerilen sorgu parametreleri:

- `personnelNo`
- `fullName`
- `status`
- `createdAtFrom`
- `createdAtTo`
- `updatedAtFrom`
- `updatedAtTo`
- `page`
- `pageSize`

Liste response'unda `password` alanı bulunmamalıdır.

### Tek kayıt oluşturma

```http
POST /api/operators
```

Request alanları:

```json
{
  "personnelNo": "10001",
  "fullName": "Ali Yılmaz",
  "password": "..."
}
```

Şifre response içinde döndürülmemelidir.

### Tek kayıt güncelleme

```http
PUT /api/operators/{personnelNo}
```

Request alanları:

```json
{
  "fullName": "Ali Yılmaz",
  "password": "..."
}
```

Şifre boşsa mevcut değeri koruma davranışı FS'te belirtilmemiştir; Öneridir.

### Silme

```http
DELETE /api/operators/{personnelNo}
```

Fiziksel silme veya pasifleştirme kararı FS'te belirtilmemiştir.

### Excel import

```http
POST /api/operators/import
Content-Type: multipart/form-data
```

Dosya alanı:

`file`

Önerilen response:

```json
{
  "totalRows": 10,
  "successCount": 8,
  "errorCount": 2,
  "errors": [
    {
      "rowNumber": 4,
      "message": "Sicil No boş."
    }
  ]
}
```

### Excel şablonu

```http
GET /api/operators/import-template
```

Response:

- `.xlsx` dosyası
- FS kolonları: Sicil No, İsim Soyisim, Şifre

## 7.3 Veri modeli

### Operatör tablosu

| Alan | Tip | Zorunlu | Açıklama |
|---|---|---:|---|
| `personnel_no` | VARCHAR | Evet | Primary key / sicil no |
| `full_name` | VARCHAR | Evet | FS'teki isim-soyisim |
| `password` | VARCHAR veya güvenli karşılık | Evet* | Popup ve import girdisi |
| `status` | VARCHAR/BOOLEAN | Öneri | Aktif/Pasif |
| `created_at` | TIMESTAMP | Öneri | Oluşturma tarihi |
| `updated_at` | TIMESTAMP | Öneri | Güncelleme tarihi |

Şifre kolonunun veri tipi, hashleme yöntemi, geri okunabilir olup olmaması ve anahtar yönetimi FS'te belirtilmemiştir. Bu nedenle burada güvenlik implementasyonu tanımlanmamıştır.

### Liste response modeli

```json
{
  "personnelNo": "10001",
  "fullName": "Ali Yılmaz",
  "status": "ACTIVE",
  "createdAt": "2026-09-09T10:30:00Z",
  "updatedAt": "2026-09-09T10:30:00Z"
}
```

Bu modelde `password` bulunmaz.

### Popup form modeli

```json
{
  "personnelNo": "10001",
  "firstName": "Ali",
  "lastName": "Yılmaz",
  "password": "",
  "status": "ACTIVE"
}
```

## 7.4 İşlem akışları

### Manuel kayıt

```text
Popup aç
  -> Alanları doldur
  -> Frontend validasyonu
  -> POST /api/operators
  -> Backend sicil no kontrolü
  -> Kayıt oluştur
  -> Listeyi yenile
```

### Manuel güncelleme

```text
Grid satırını seç
  -> Popup aç
  -> Alanları düzenle
  -> Frontend validasyonu
  -> PUT /api/operators/{personnelNo}
  -> Kayıt güncelle
  -> Listeyi yenile
```

### Excel import

```text
Dosya seç
  -> Dosya/kolon kontrolü
  -> Satır validasyonu
  -> Hatalı/geçerli özetini göster
  -> Kullanıcı onayı
  -> POST /api/operators/import
  -> Import sonucu göster
  -> Listeyi yenile
```

### Şifre veri akışı

```text
Popup veya Excel girdisi
  -> Backend create/update/import isteği
  -> Şifre grid response'larına dahil edilmez
  -> Şifre liste endpoint'inden döndürülmez
  -> Şifre liste/export sonuçlarında gösterilmez
```

Bu akış login veya authentication işlemi içermez.

---

# 8. Wireframe

## 8.1 Ana ekran

```text
┌──────────────────────────────────────────────────────────────────────────────┐
│ MES022 – Operatör Anaveri Ekleme / Güncelleme                                │
├──────────────────────────────────────────────────────────────────────────────┤
│ Filtreler                                                                     │
│                                                                              │
│ Sicil No       [________________]   Ad Soyad [___________________________]   │
│ Durum          [Tümü        v]       Oluşturma Tarihi [____] - [____]        │
│ Güncelleme Tarihi [____] - [____]                                             │
│                                                                              │
│ [Filtrele] [Temizle]                                                         │
├──────────────────────────────────────────────────────────────────────────────┤
│ [Yeni Operatör Ekle] [Excel Şablonu İndir] [Excel İçe Aktar]                 │
├──────────────────────────────────────────────────────────────────────────────┤
│ Operatör Listesi                                                             │
│                                                                              │
│ Sicil No │ Ad Soyad          │ Durum  │ Oluşturma Tarihi │ Güncelleme Tarihi │
│──────────┼───────────────────┼────────┼──────────────────┼───────────────────│
│ 10001    │ Ali Yılmaz        │ Aktif  │ 09.09.2026       │ 09.09.2026        │
│ 10002    │ Ayşe Kaya         │ Pasif  │ 09.09.2026       │ 09.09.2026        │
│                                                                              │
│ İşlemler: [Güncelle] [Sil]                                                   │
├──────────────────────────────────────────────────────────────────────────────┤
│ Toplam kayıt: 2                                      [<] 1 [>]               │
└──────────────────────────────────────────────────────────────────────────────┘

Not: Şifre bu ekranda hiçbir kolon, filtre veya liste bilgisi olarak gösterilmez.
```

## 8.2 Yeni operatör popup

```text
                 ┌────────────────────────────────────┐
                 │ Yeni Operatör Ekle             [X]  │
                 ├────────────────────────────────────┤
                 │ Sicil No *                          │
                 │ [______________________________]    │
                 │                                    │
                 │ Ad *                                │
                 │ [______________________________]    │
                 │                                    │
                 │ Soyad *                             │
                 │ [______________________________]    │
                 │                                    │
                 │ Şifre *                             │
                 │ [••••••••••••••••••••••••••••]      │
                 │                                    │
                 │ Durum *                             │
                 │ [Aktif                         v]  │
                 ├────────────────────────────────────┤
                 │              [İptal] [Kaydet]       │
                 └────────────────────────────────────┘
```

## 8.3 Operatör güncelle popup

```text
                 ┌────────────────────────────────────┐
                 │ Operatör Güncelle              [X]  │
                 ├────────────────────────────────────┤
                 │ Sicil No                            │
                 │ [10001                       ]      │
                 │                                    │
                 │ Ad *                                │
                 │ [Ali                         ]      │
                 │                                    │
                 │ Soyad *                             │
                 │ [Yılmaz                      ]      │
                 │                                    │
                 │ Şifre                               │
                 │ [Yeni şifre giriniz               ] │
                 │                                    │
                 │ Durum *                             │
                 │ [Aktif                         v]  │
                 ├────────────────────────────────────┤
                 │              [İptal] [Kaydet]       │
                 └────────────────────────────────────┘
```

Öneri: Güncelleme popup'ında mevcut şifre gösterilmez; alan yalnızca yeni değer girmek için kullanılır.

## 8.4 Excel içe aktarma popup

```text
                 ┌────────────────────────────────────┐
                 │ Excel İçe Aktar                 [X] │
                 ├────────────────────────────────────┤
                 │ Beklenen kolonlar:                  │
                 │ Sicil No | İsim Soyisim | Şifre     │
                 │                                    │
                 │ Dosya                                │
                 │ [Dosya seç]  operatorler.xlsx       │
                 │                                    │
                 │ [Şablon indir]                       │
                 │                                    │
                 │ Validasyon özeti:                    │
                 │ Toplam: 10  Başarılı: 8  Hatalı: 2 │
                 │                                    │
                 │ Hatalı satırlar:                     │
                 │ Satır 4 - Sicil No boş              │
                 │ Satır 7 - Sicil No mevcut           │
                 ├────────────────────────────────────┤
                 │              [İptal] [Yükle]         │
                 └────────────────────────────────────┘
```

---

# 9. FS Gereksinimi ve Öneri Ayrımı

## FS'ten gelenler

- MES022 operatör anaveri bakım ekranıdır.
- Sicil numarası key alandır.
- İsim-soyisim bilgisi tutulur.
- Şifre bilgisi tutulur.
- Yeni operatör eklenebilir.
- Mevcut operatör güncellenebilir.
- Operatör silinebilir.
- Excel şablonu indirilebilir.
- Excel'de Sicil No, İsim Soyisim ve Şifre kolonları bulunur.
- Excel ile toplu operatör sicil kaydı eklenebilir.
- Veriler MII vardiya giriş-çıkış takibinde kullanılır.

## Kullanıcı tasarım kararından gelenler

- Şifre ana gridde gösterilmez.
- Şifre popup'ta gösterilir.
- Şifre kullanıcı listelerinde gösterilmez.
- Gridde Sicil No, Ad Soyad, Durum, Oluşturma Tarihi ve Güncelleme Tarihi önerilir.

## Öneriler / FS'te belirtilmeyenler

- Ad ve soyadın popup'ta ayrı alanlar olması
- Durumun popup'ta düzenlenmesi
- Oluşturma/Güncelleme tarihleri
- Filtre alanları
- Sayfalama ve sıralama
- Dosya ön izleme
- Satır bazlı hata raporu
- Hatalı/geçerli satırların birlikte işlenme stratejisi
- Fiziksel silme veya pasife alma tercihi
- Güncellemede boş şifre alanının mevcut değeri koruması
- Şifre uzunluğu ve karakter kuralları
- Şifre saklama/şifreleme yöntemi
- API URL'leri
- SAPUI5 klasör ve dosya yapısı
- Rol ve yetki matrisi
- Hata ve başarı mesajlarının metinleri
- Maksimum Excel dosya boyutu ve satır sayısı

---

# 10. Kapsam dışı

Aşağıdaki fonksiyonlar bu tasarımda yer almaz:

- Login ekranı
- Authentication / giriş doğrulama akışı
- Operatör giriş ekranı
- Kullanıcı oturum yönetimi
- Şifreyi gridde gösterme
- Şifreyi liste filtresi olarak kullanma
- Şifreyi kullanıcı listesi export'unda gösterme
- Şifreyi mevcut değeriyle ana ekranda gösterme

Şifre yalnızca FS gereği veri bakım popup'ı ve Excel toplu veri akışında yer alır; ana liste görünümünde yer almaz.
